This readme accompanies the Gravity Modeling Environment (GME) package.
Created by the Gravity Modeling Group at the United States International Trade Commission (USITC).
Gravity Modeling Group: https://www.usitc.gov/data/gravity/experts.htm.

Installation instructions and documentation are available at https://www.usitc.gov/data/gravity/gme_docs/

Also, see USITC's gravity portal at https://gravity.usitc.gov
